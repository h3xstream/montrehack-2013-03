package ca.hackfest.anon.util.crypto;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

/**
 * 
 */
public class Rc4Cipher {
	
	private final String KEY_ALGORITHM = "PBEWithMD5AndDES";
	private final String CIPHER_ALGORITHM = "RC4";

	//Password use to generate the key
	private final char[] password;
    
	//Key definition
    private static SecretKey key;
    
    public Rc4Cipher(char[] password) {
    	this.password = password;
    }
    
    public void initKey() throws InvalidKeySpecException, NoSuchAlgorithmException {
    	
    	if(key == null) {
    		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(KEY_ALGORITHM);
    		key = keyFactory.generateSecret(new PBEKeySpec(password));
    	}
    }
    
	public byte[] encrypt(byte[] plainText) throws Exception {
        if(plainText == null) return null;
        
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM,BouncyCastleProvider.PROVIDER_NAME);
        cipher.init(Cipher.ENCRYPT_MODE, key);

        InputStream inputStream = new ByteArrayInputStream(plainText);
        CipherInputStream cipherInputStream = new CipherInputStream(inputStream, cipher);

        ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();
        byte[] buffer = new byte[512];
        int lengthRead = 0;
        while((lengthRead = cipherInputStream.read(buffer)) != -1) {
        	outBuffer.write( buffer, 0, lengthRead );
        }
        
		return outBuffer.toByteArray();
    }
	
	public byte[] decrypt(byte[] ct) throws Exception {
		if(ct == null) return null;
		
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM,BouncyCastleProvider.PROVIDER_NAME);
        cipher.init(Cipher.DECRYPT_MODE, key);
		
		InputStream inputStream = new ByteArrayInputStream(ct);

        CipherInputStream cipherInputStream = new CipherInputStream(inputStream, cipher);
		
        ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();
        byte[] buffer = new byte[512];
        int lengthRead = 0;
        while((lengthRead = cipherInputStream.read(buffer)) != -1) {
        	outBuffer.write( buffer, 0, lengthRead );
        }
		
		return outBuffer.toByteArray();
	}
	
	
}
