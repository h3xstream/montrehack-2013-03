
# xor two strings of different lengths
def strxor(a, b):
    if len(a) > len(b):
        return "".join([chr(ord(x) ^ ord(y)) for (x, y) in zip(a[:len(b)], b)])
    else:
        return "".join([chr(ord(x) ^ ord(y)) for (x, y) in zip(a, b[:len(a)])])

# Binary representation of a string. Bits are group per byte
def binary(data_input):
    return [ bin(ord(ch))[2:].zfill(8) for ch in data_input ]

#Hex encode/decode
from binascii import unhexlify, hexlify
#Base64 encode/decode
from base64 import b64decode, b64encode


import code
code.interact(local=locals())