package ca.hackfest.anon.util.crypto;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AesCipher {

	private final byte[] masterKey;
	
	public AesCipher(byte[] masterKey) {
		this.masterKey = masterKey;
	}
	
	public byte[] encrypt(byte[] pt,byte[] iv) throws Exception {
		//iv and key
		IvParameterSpec ips = new IvParameterSpec(iv);
		SecretKey aesKey = new SecretKeySpec(masterKey, "AES");

		// Create the encrypt cipher
		Cipher encryptCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		encryptCipher.init(Cipher.ENCRYPT_MODE, aesKey, ips);

		// Encrypt the cleartext
		byte[] ciphertext = encryptCipher.doFinal(pt);
		return ciphertext;
	}
	
	public byte[] decrypt(byte[] ct,byte[] iv) throws Exception {
		//iv and key
		IvParameterSpec ips = new IvParameterSpec(iv);
		SecretKey aesKey = new SecretKeySpec(masterKey, "AES");

		// Decryption cipher
		Cipher decryptCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		decryptCipher.init(Cipher.DECRYPT_MODE, aesKey, ips);
		
		// Decrypt the cleartext
		byte[] deciphertext = decryptCipher.doFinal(ct);
		return deciphertext;
	}
}
